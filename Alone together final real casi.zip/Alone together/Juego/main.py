
import time #imports niveles y jugador


from levels.nivel1 import jugador1 as nvl1_j1
from levels.nivel1 import jugador2 as nvl1_j2

from levels.nivel2 import jugador1 as nvl2_j1    #Se importan las funciones de todos los niveles y jugador uno y dos
from levels.nivel2 import jugador2 as nvl2_j2

from levels.nivel3 import jugador1 as nvl3_j1
from levels.nivel3 import jugador2 as nvl3_j2

#muy importante instalar pygame poniendo pip install pygame en la consola por fa profe, ya el de la ventana sirve
import pygame  #librer'ia para reproducir musica
pygame.mixer.init() #iniciar
pygame.mixer.music.load('Hollow Knight OST - Crystal Peak.mp3') #cargar cancion
pygame.mixer.music.play(loops=-1, start=5, fade_ms=3000) #Reproducir -1 es infinito o hata pausar
# epieza en el segundo 5 con 3 segundos de fade de entrada

respuesta=True
print("""
🧠💣 ALONE TOGETHER – Un juego cooperativo de desactivación de bombas

Alone Together es un juego cooperativo donde dos jugadores deben comunicarse a la perfección para desactivar una bomba antes de que sea demasiado tarde.
Uno es el Policía, atrapado frente al explosivo con cables, códigos y módulos peligrosos.
El otro es el Experto, lejos de la escena, con acceso al Manual oficial de desactivación, lleno de instrucciones extrañas, acertijos, códigos cifrados y trampas psicológicas.

Pero hay un detalle:
Ninguno puede ver lo que el otro tiene. Solo la comunicación los salvará.

Tu misión es simple:
🟢 Sigue instrucciones complicadas.
🔴 Responde preguntas crípticas.
🔵 Descifra códigos morse, binarios y cifrados.
🟡 Elige las palabras correctas.
🟣 Evita cortar el cable equivocado.

Tu error puede detonar todo.
Tu acierto, salvar la misión.

¿Podrán trabajar juntos… incluso estando separados?
Bienvenido a ALONE TOGETHER: donde hablar bien es más importante que ser valiente.
""")

while respuesta:  #Ciclo para reiniciar el juego

    print("\n1) Nivel 1")
    print("\n2) Nivel 2")
    print("\n3) Nivel 3\n")
    nivel = int(input("Selecciona el nivel de dificultad: "))
    print("\nCargando...\n")
    time.sleep(3)


    print("\n1) Player 1")
    print("\n2) Player 2\n")
    jugador = int(input("Jugador: "))
    print("\nCargando...\n")
    time.sleep(2)

#esto es practicamente todo el juego acomodado ya bien por niveles
        
    if nivel == 1 and jugador==1:
        nvl1_j1.run()

    elif nivel== 1 and jugador ==2:
        nvl1_j2.run()
        
    elif nivel== 2 and jugador ==1:
        nvl2_j1.run()
        
    elif nivel== 2 and jugador ==2:
        nvl2_j2.run()
        
    elif nivel== 3 and jugador ==1:
        nvl3_j1.run()

    elif nivel== 3 and jugador ==2:
        nvl3_j2.run()

    else:
        print("Nivel no válido.")
    
    respuesta=bool(int(input("Quieres volver a jugar? \n0) no \n1) si\n ")))
print("Gracias por jugar 💀👌")  
  
pygame.quit() #Cerrar reproductor de musicaa