import tkinter as tk
import time

tiempo = 1000 

def Ventana():
    global tiempo
    ventana = tk.Tk()
    ventana.title("Alone Together - Timer")
    label = tk.Label(ventana, font=("Magneto", 50)) #fuente del texto y tamaño, me dejo con una que encontre en word 
    label.pack()

    def ticks():
        global tiempo
        if tiempo >= 0:#mientras el tiempo sea mayor a 0 ->
            label.config(text=f"{tiempo}") #imprime el tiempo
            tiempo -= 1 #le resta uno cada mil ticks un segundo
            ventana.after(1000, ticks)#mil ticks un segundo, cada segundo resta uno al tiempo  y lo imprime
        else:
            label.config(text="💥 Se acabó el tiempo")#lo imprime en la ventana
            print("💥 Se acabó el tiempo") #para que imrima en el codigo y no en la ventana
    ticks() #para que corra la funcion de lo ticks
    ventana.mainloop() # para que corra la funcion de la ventana en un loop y no se cierre solita

    #falta buscar si hay una forma de cerrar maualmente la ventana cuando acabe el juego para asegurar