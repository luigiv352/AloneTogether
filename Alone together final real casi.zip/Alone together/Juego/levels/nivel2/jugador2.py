import time
import tkinter as tk    #Imports
import threading
import Ventanatimer
from Ventanatimer import Ventana

reset="\033[0m"
rojo = "\033[31m"
amarillo="\033[33m"  #Colores
verde = "\033[32m"
azul = "\033[34m"
morado = "\033[35m"

def run():

    threading.Thread(target=Ventana, daemon=False).start() # abrir ventana de timer en segundo plano

    print(" Hola jugador DOS, bienvenido a Alone together, estas jugando el nivel 2")
    print(
    "🧠 CENTRO DE OPERACIONES - UNIDAD ANTIBOMBAS 🧠\n"
    "\n"
    "Hola, jugador DOS.\n"
    "Tu rol es el" + amarillo + " EXPERTO " + reset + "en desactivación de explosivos.\n"
    "\n"
    "Tu compañero, el POLICÍA, está en la escena del crimen frente a la bomba.\n"
    "Él puede ver los cables, tú tienes el MANUAL con las instrucciones.\n"
    "\n"
    + amarillo + "📞 COMUNICACIÓN:\n" + reset +
    "Escucha con atención lo que el POLICÍA describe.\n"
    "No puedes ver la bomba, así que cada detalle importa.\n"
    "\n"
    + amarillo + "⚠️ REGLAS:\n" + reset +
    "- NO CIERRES LA VENTANA DEL TIEMPO"
    "- No hables por hablar: da instrucciones claras y precisas.\n"
    "- Tienes solo 3 oportunidades de equivocarte, de lo contrario todo terminara... de forma explosiva. 💥\n"
    "- Usa la lógica del manual para guiarlo paso a paso.\n"
    "\n"
    "Mantén la calma, experto. El destino está en tus manos... ⏱️\n"
    )
    print(rojo+"           ////////////// Xxx Manual de desactivación de bombas xXX //////////////            "+reset)
    print("""
          

          
        Código secreto 554312
        
        Palabra secreta: "🌙🕸️🕰️🌙☀️   🪐  🔺☀️🌙🧠💀🕊️"
        
        Acertijo ... por su nombre desaparece
        """)
    print( verde+ "  \nCable verde"+rojo+" y cable rojo    ⚫ ⬛ ⬜ ⬛ ⚪⬜ ⚫ ⚫ ⬜ ⚪ ⚪ ⚪ \n"+reset)
    p1=input("Quieres una pista para el acertijo??").lower()
    if p1=="si":
        print(verde+"Pista: --"+rojo+"  SHHHHHH"+reset)