import time
import Ventanatimer
from Ventanatimer import Ventana
import threading

reset="\033[0m"
rojo = "\033[31m"
amarillo="\033[33m"  #Colores
verde = "\033[32m"
azul = "\033[34m"
morado = "\033[35m"
correctas = 0
errores = 0

def run(): #Lo que corre

    threading.Thread(target=Ventana, daemon=False).start() # abrir ventana de timer en segundo plano

    print(" Hola jugador UNO, bienvenido a Alone together, estas jugando el nivel 2")
    print("🚨 ESCENA DEL CRIMEN - UNIDAD ANTIBOMBAS 🚨\n"
    "\n"
    "Hola, agente.\n"
    "Tu rol es el"+amarillo+" POLICÍA "+reset+"en la escena del crimen.\n"
    "\n"
    "Tienes frente a ti una bomba con 5 cables: 🔴 🔵 🟢 🟡 ⚫\n"
    "Debes cortarlos ... pero no estás solo.\n"
    "Tu compañero, el EXPERTO, tiene el manual con las instrucciones.\n"
    "\n"
    +amarillo+"📞 COMUNICACIÓN:\n"+reset+
    "Habla con el EXPERTO. Diles lo que vez. No puedes mostrarle la bomba, solo describirla.\n"
    "Él te dirá qué hacer según lo que le digas.\n"
    "\n"
    +amarillo+"⚠️ REGLAS:\n"+reset+
    "- NO CIERRES LA VENTANA DEL TIEMPO"
    "- No cortes un cable sin confirmar con el EXPERTO.\n"
    "- La comunicación es clave: una palabra mal dicha puede costar la misión.\n"
    "- Tienes 3 intentos. Si cortas el cable equivocado... 💥\n"
    "\n"
    "Confía en tu instinto, agente. El tiempo corre... ⏱️\n")
   


    print(rojo+"           ////////////// XxxBombaxXX //////////////            \n"+reset)
    
    print(rojo+"cable rojo y "+verde+" Cable verde\n"
    " Negro = 0\n"
    " Blanco = 1\n\n"+rojo+
    " Círculo = a\n"
    "  Cuadrado = b\n\n"
    +azul+"Cable azul\n"
   " 1  --.\n"
   " 2  .-\n"
   " 3  ---\n"
   " 4  ...\n"
   " 5  -.-\n"
   " 6  .-.\n"
   " 7  .--"
   +reset+"\n"
   +amarillo+"Cable amarillo \n"
   "A = ☀️    N = 🕯️\n"
   "B = 🌙    O = 🕸️\n"
   "C = 🔺    P = 🧭\n"
   "D = 🔹    Q = 🐉\n"
   "E = 💀    R = 🪞\n"
   "F = ⚙️    S = 🕊️\n"
   "G = 🌀    T = ⚡\n"
+reset+
   "..... \n"
   ""
   +morado+"Cable morado "

   "Acertijo ¿Qué ocurre una en un minuto, dos veces..."+reset
   )
   
    print("""
        \n1) Ingresa un codigo binario 🟢: 
        \n2) Ingresa codigo cifrado en a y b 🔴:  
        \n3) Ingresa un codigo morse 🔵: 
        \n4) Ingresa la palabra secreta 🟡:  
        \n5) Ingresa la repsuesta al acertijo 🟣:
         
         """)
    correctas=0
    errores=0

    while correctas < 5 and errores < 3:
        ask = int(input("¿Qué pregunta quieres resolver? (1-5): "))
        if ask == 1:
            cable1 = input("Ingresa un código binario 🟢: ").lower()
            if cable1 == "001011001111":
                correctas += 1
                print("✅ Respuesta correcta, cortaste el cable correctamente")
            else:
                errores += 1
                print("❌ UPPS, te equivocaste. Cuidado, 3 errores y la bomba explota")
    
        elif ask == 2:
            cable2 = input("Ingresa código cifrado en a y b 🔴: ").lower()
            if cable2 == "abbbabaabaaa":
                correctas += 1
                print("✅ Respuesta correcta, cortaste el cable correctamente")
            else:
                errores += 1
                print("❌ UPPS, te equivocaste. Cuidado, 3 errores y la bomba explota")
    
        elif ask == 3:
            cable3 = input("Ingresa un codigo morse 🔵: ").lower()
            if cable3 == "--..----.-..--...-.-":
                correctas += 1
                print("✅ Respuesta correcta, cortaste el cable correctamente")
            else:
                errores += 1
                print("❌ UPPS, te equivocaste. Cuidado, 3 errores y la bomba explota")
        
        elif ask == 4:
            cable4 = input("Ingresa la palabra secreta 🟡: ").lower().strip()
            if cable4 == "bomba y cables":
                correctas += 1
                print("✅ Respuesta correcta, cortaste el cable correctamente")
            else:
                errores += 1
                print("❌ UPPS, te equivocaste. Cuidado, 3 errores y la bomba explota")
        
        elif ask == 5:
            cable5 = input("Ingresa la respuesta al acertijo 🟣: ").lower().strip()
            if cable5 == "m":
                correctas += 1
                print("✅ Respuesta correcta, cortaste el cable correctamente")
            else:
                errores += 1
                print("❌ UPPS, te equivocaste. Cuidado, 3 errores y la bomba explota")
        
        else:
            print("⚠️ Pregunta inválida, elige un número entre 1 y 5.")

    if correctas >= 5:
             print(
            verde + "\n🎉 ¡BOMBA DESACTIVADA! 🎉" + reset +
            "\n¡Felicidades, agente! Has demostrado precisión, valentía y trabajo en equipo."
            "\nLa ciudad está a salvo gracias a tus reflejos y decisiones inteligentes. 👮‍♂️💥"
            "\n¡El EXPERTO y tú han completado la misión con éxito! ✅"
            )
    else:
            print(
            rojo + "\n💥 ¡MISIÓN FALLIDA! 💥" + reset +
            "\nLa bomba ha explotado… 😱"
            "\nEl tiempo se acabó y la ciudad sufrió las consecuencias."
            "\nNo te desanimes, agente: cada error es una lección para la próxima misión. ⚠️"
            )